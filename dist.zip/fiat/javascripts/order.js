$(function(){
	// FastClick.attach(document.body);
	$(".imgRight").click(function(){
		window.location.href='relation.html';
	});
	$(".imgLeft").click(function(){
		window.history.back(-1); 
	})

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})